# cron-analysis-using-c

* * * * * Command

Minute - first star indicates minute, 8 means every minute (0-59)
Hour - second star is for Hours, * indicates every hour (0-23)
Day of the month -* means it can be anyday
Month - * means every month
day of the week - * means it can be anyday

and to run the job everyday, we need to make the day of the month and day of the week *



